POLPICK GEM DETECTOR — V2.0 (source Android)

Cette version ajoute une capture d'écran ponctuelle via l'autorisation Android MediaProjection.
L'utilisateur doit appuyer sur le bouton et accepter la boîte de dialogue Android. La capture
est affichée dans l'application et n'est pas envoyée à un serveur par ce code.

Limites connues :
- La capture est ponctuelle, pas un flux permanent ni une fenêtre flottante.
- Aucune reconnaissance automatique de diamant n'est encore implémentée.
- Les cases cachées ne peuvent pas être prédites à partir d'une simple capture.
- Certains appareils peuvent empêcher la capture de contenus protégés ou sécurisés.

Configuration : minSdk 29 (Android 10), compileSdk 35, targetSdk 32.
C'est un projet source, pas un APK compilé. Il doit être compilé dans un environnement Android.
