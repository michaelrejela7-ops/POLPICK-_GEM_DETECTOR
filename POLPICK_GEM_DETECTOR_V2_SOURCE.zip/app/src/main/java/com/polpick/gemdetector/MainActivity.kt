package com.polpick.gemdetector

import android.app.Activity
import android.media.projection.MediaProjectionManager
import android.media.projection.MediaProjection
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private val captureRequest = 4102
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private val handler = Handler(Looper.getMainLooper())
    private val cells = IntArray(30) { 0 } // manually confirmed: unknown / gem / non-gem

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 24, 18, 18)
            setBackgroundColor(Color.rgb(16,31,43))
        }
        root.addView(TextView(this).apply {
            text = "💎 POLPICK GEM DETECTOR"
            textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "VERSION 2.0 • CAPTURE À LA DEMANDE"
            textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(0,8,0,16)
        })
        val scan = Button(this).apply {
            text = "AUTORISER ET CAPTURER L'ÉCRAN"
            isAllCaps = false
            setOnClickListener { requestScreenCapture() }
        }
        root.addView(scan)
        status = TextView(this).apply {
            text = "Aucune capture effectuée."
            textSize = 14f; setTextColor(Color.WHITE); setPadding(4,14,4,14)
        }
        root.addView(status)
        preview = ImageView(this).apply {
            adjustViewBounds = true
            setBackgroundColor(Color.rgb(32,55,70))
        }
        root.addView(preview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        root.addView(TextView(this).apply {
            text = "La capture est demandée uniquement après ton appui et l'accord Android. Elle reste sur le téléphone. Cette version affiche l'image capturée mais ne prétend pas encore reconnaître automatiquement les diamants cachés."
            textSize = 12f; setTextColor(Color.rgb(255,210,120)); setPadding(4,12,4,8)
        })
        setContentView(root)
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated by Android but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != captureRequest) return
        if (resultCode != RESULT_OK || data == null) {
            status.text = "Capture annulée : aucune image n'a été prise."
            return
        }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            captureOneFrame()
        } catch (e: Exception) {
            status.text = "Impossible de démarrer la capture : ${e.message ?: "erreur Android"}"
            stopProjection()
        }
    }

    private fun captureOneFrame() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "PolpickGemDetectorCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
        status.text = "Capture en cours…"
        handler.postDelayed({
            try {
                val image = reader?.acquireLatestImage()
                if (image == null) {
                    status.text = "Aucune image reçue. Réessaie en gardant Polpick affiché."
                } else {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val full = Bitmap.createBitmap(
                        width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
                    )
                    full.copyPixelsFromBuffer(buffer)
                    val cropped = Bitmap.createBitmap(full, 0, 0, width, height)
                    preview.setImageBitmap(cropped)
                    image.close()
                    full.recycle()
                    status.text = "Capture terminée. Image affichée localement. Appuie à nouveau pour une nouvelle capture."
                }
            } catch (e: Exception) {
                status.text = "Erreur pendant la capture : ${e.message ?: "inconnue"}"
            } finally {
                stopProjection()
            }
        }, 700)
    }

    private fun stopProjection() {
        virtualDisplay?.release()
        virtualDisplay = null
        reader?.close()
        reader = null
        projection?.stop()
        projection = null
    }

    override fun onDestroy() {
        stopProjection()
        super.onDestroy()
    }
}
