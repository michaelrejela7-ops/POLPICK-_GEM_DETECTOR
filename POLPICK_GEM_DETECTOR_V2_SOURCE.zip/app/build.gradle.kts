plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.polpick.gemdetector"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.polpick.gemdetector"
        minSdk = 29
        targetSdk = 32
        versionCode = 3
        versionName = "2.0"
    }
}
